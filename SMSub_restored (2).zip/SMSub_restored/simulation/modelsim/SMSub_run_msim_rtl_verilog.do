transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vlog -vlog01compat -work work +incdir+C:/Users/makhu/OneDrive/QuartusProjects/novayasro2/SMSub_restored {C:/Users/makhu/OneDrive/QuartusProjects/novayasro2/SMSub_restored/SM.v}
vlog -vlog01compat -work work +incdir+C:/Users/makhu/OneDrive/QuartusProjects/novayasro2/SMSub_restored {C:/Users/makhu/OneDrive/QuartusProjects/novayasro2/SMSub_restored/smsubtractor_4bit.v}
vlog -vlog01compat -work work +incdir+C:/Users/makhu/OneDrive/QuartusProjects/novayasro2/SMSub_restored {C:/Users/makhu/OneDrive/QuartusProjects/novayasro2/SMSub_restored/HalfSM.v}

