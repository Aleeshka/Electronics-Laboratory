`timescale 1ns/1ps

module smsubtractor_4bit_tb;

reg [3:0] A, B;
wire [3:0] D;
wire Bout;


smsubtractor_4bit uut (
    .A(A),
    .B(B),
    .D(D),
    .Bout(Bout)
);

initial begin
        $monitor("A=%b B=%b | Diff=%b Bout=%b",
		  A, B, D, Bout);   
		A = 4'b0110; B = 4'b0011; #10;
      A = 4'b0100; B = 4'b0101; #10;
      A = 4'b1111; B = 4'b0001; #10;
      A = 4'b0000; B = 4'b0001; #10;

    $stop;
end

endmodule