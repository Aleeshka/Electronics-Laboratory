`timescale 1ns/1ps

module smsubtractor_4bit_tb;

reg [3:0] A, B;
wire [3:0] D;
wire Bout;

smsubtractor_4bit uut (
    .A(A),
    .B(B),
    .D(D),
    .Bout(Bout)
);

initial begin
    // 1) включаем запись волн
    $dumpfile("smsubtractor_4bit.vcd");   // имя файла с волнами
    $dumpvars(0, smsubtractor_4bit_tb);   // пишем все сигналы внутри tb

    // 2) печать в консоль (как у тебя)
    $monitor("t=%0t A=%b B=%b | Diff=%b Bout=%b", $time, A, B, D, Bout);

    // 3) тесты
    A = 4'b0110; B = 4'b0011; #10;
    A = 4'b0100; B = 4'b0101; #10;
    A = 4'b1111; B = 4'b0001; #10;
    A = 4'b0000; B = 4'b0001; #10;

    $finish; // лучше чем $stop для автоматического завершения
end

endmodule