module SM (
    input A,
    input B,
    input Cin,
    output SUM,
    output Cout
);

wire S1, C1, C2;

HalfSM X1 (A, B, S1, C1);
HalfSM X2 (S1, Cin, SUM, C2);

assign Cout = C1 | C2;

endmodule