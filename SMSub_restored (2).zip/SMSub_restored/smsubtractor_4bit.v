module smsubtractor_4bit (
    input [3:0] A,
    input [3:0] B,
    output [3:0] D,
    output Bout
);

wire [3:0] B_inv;
wire c1, c2, c3, c4;


assign B_inv = ~B;


SM FA0 (A[0], B_inv[0], 1'b1, D[0], c1);
SM FA1 (A[1], B_inv[1], c1,   D[1], c2);
SM FA2 (A[2], B_inv[2], c2,   D[2], c3);
SM FA3 (A[3], B_inv[3], c3,   D[3], c4);


assign Bout = ~c4;

endmodule